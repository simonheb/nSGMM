#ifndef tic_toc_H
#define tic_toc_H

#include <RcppArmadillo.h>
#include <iostream>


using namespace arma;

void toc();
void tic(int counter);
void tictoc(int limit);


#endif